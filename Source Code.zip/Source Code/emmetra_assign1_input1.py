import cv2
import numpy as np

def load_raw_image(file_path):
    raw_image = np.fromfile(file_path, dtype=np.uint16).reshape((1280, 1920)) 
    raw_image = (raw_image / 16).astype(np.uint8) 
    return raw_image


def demosaic(image):
    demosaiced_image = cv2.cvtColor(image, cv2.COLOR_BAYER_GR2RGB)
    return demosaiced_image

def white_balance(image):
    mean_vals = np.mean(image, axis=(0, 1))
    balanced_image = (image * (np.mean(mean_vals) / mean_vals)).clip(0, 255).astype(np.uint8)
    return balanced_image


def gaussian_denoise(image, kernel_size=5):
    return cv2.GaussianBlur(image, (kernel_size, kernel_size), 0)


def gamma_correction(image, gamma=2.2):
    look_up_table = np.array([((i / 255.0) ** (1.0 / gamma)) * 255 for i in np.arange(0, 256)]).astype("uint8")
    return cv2.LUT(image, look_up_table)


def sharpen(image):
    blurred = cv2.GaussianBlur(image, (5, 5), 1.5)
    sharpened_image = cv2.addWeighted(image, 1.5, blurred, -0.5, 0)
    return sharpened_image

raw_image = load_raw_image("C:/Users/moni2/Desktop/emmetra/assignment1_input1.raw")
demosaiced = demosaic(raw_image)
white_balanced = white_balance(demosaiced)
denoised = gaussian_denoise(white_balanced)
gamma_corrected = gamma_correction(denoised)
sharpened = sharpen(gamma_corrected)

cv2.imwrite('output_image.png', sharpened)
cv2.imwrite('demosaiced_image.png', demosaiced)
cv2.imwrite('white_balanced_image.png', white_balanced)
cv2.imwrite('denoised_image.png', denoised)
cv2.imwrite('gamma_corrected_image.png', gamma_corrected)


