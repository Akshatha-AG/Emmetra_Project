import cv2
import numpy as np
def load_images(filenames, target_size=(1920, 1080)):
    images = []
    for file in filenames:
        img = cv2.imread(file, cv2.IMREAD_UNCHANGED)
        if img is None:
            print(f"Failed to load image: {file}")
        else:
            img = cv2.resize(img, target_size)
            images.append(img)
    return images
def merge_hdr(images, times):
    merge_debevec = cv2.createMergeDebevec()
    hdr = merge_debevec.process(images, times=times)
    hdr = np.float32(hdr) 
    hdr_max = np.max(hdr)
    if hdr_max > 0:
        hdr /= hdr_max      
    return hdr

def tone_map(hdr_image):
    tonemap = cv2.createTonemapDrago(1.0, 0.7)
    ldr_image = tonemap.process(hdr_image)

    ldr_image = np.nan_to_num(ldr_image, nan=0.0, posinf=1.0, neginf=0.0)
    ldr_image = (ldr_image * 255).clip(0, 255).astype('uint8')
    
    return ldr_image

filenames = [
    'C:/Users/moni2/Desktop/emmetra/exposure_high.jpeg', 
    'C:/Users/moni2/Desktop/emmetra/exposure_medium.jpeg', 
    'C:/Users/moni2/Desktop/emmetra/exposure_low.jpeg'
]

images = load_images(filenames, target_size=(1920, 1080))

times = np.array([1/30, 1/8, 1/2], dtype=np.float32)

hdr_image = merge_hdr(images, times)
ldr_image = tone_map(hdr_image)

output_path = 'C:/Users/moni2/Desktop/emmetra/hdr_output.png'
cv2.imwrite(output_path, ldr_image)

print(f"HDR processing complete. Output saved as {output_path}.")
